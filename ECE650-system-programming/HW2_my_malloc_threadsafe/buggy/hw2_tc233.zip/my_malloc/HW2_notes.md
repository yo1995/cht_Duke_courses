## mutex lock related

在Linux中使用线程 - pthread_mutex_t
https://www.cnblogs.com/zengkefu/p/5683957.html

## general tests

valgrind --leak-check=full --show-leak-kinds=all ./thread_test_malloc_free_change_thread

valgrind --leak-check=full --show-leak-kinds=all ./thread_test_measurement

## bug spotted

after hours of undirected debugging, finally I found that the problem does not come from TLS, but from merge function.

## questions to ask

- when to init the mutex lock?

most sample code I've seen initializes the lock in main function. since my code does not have the main function to do that, i just create the lock as a global variable.

- either using RWLOCK or MUTEX LOCK?

according to ref, rwlock has worse performance than mutex lock. http://blog.chinaunix.net/uid-20662820-id-4211959.html

but to my expectation, properly written rwlock should be faster than mutex, since we can read simultaneously without exclude other threads. investigate later.

- Thread-Local Storage

what is TLS?

