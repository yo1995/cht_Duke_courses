clear
for N = 0:18
    draw_colorful_blocks(N);
    pause(0.5)
end