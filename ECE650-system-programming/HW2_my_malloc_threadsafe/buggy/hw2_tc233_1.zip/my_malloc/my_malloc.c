#include "my_malloc.h"

/* initializations */

// init a head node
metadata_block* head = NULL;  
// init a tail node
metadata_block* tail = NULL;  
// init a head node for free list
metadata_block* free_head = NULL;
// init TLS pointers
__thread metadata_block* head_TLS = NULL;  
__thread metadata_block* tail_TLS = NULL;  
__thread metadata_block* free_head_TLS = NULL;
// mutex lock as a global variable. see in report
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
// mutex lock only for sbrk()
pthread_mutex_t sbrk_lock = PTHREAD_MUTEX_INITIALIZER;

/* helper funcs */

/**
 * check the validity of the to-free pointer
 * to see if it is malloc'd by my malloc func
 * @param  ptr the pointer to check    
 * @return     true: valid false: invalid
 */
bool metadata_check(void* ptr) {
    /*
     * do I need to add memory bound check here?
     */
    if(head == NULL || ptr == NULL) {
        return false;
    }
    metadata_block* check;
    check = ptr - METADATA_SIZE;
    return ptr == check -> check_ptr;
}

bool metadata_check_TLS(void* ptr) {
    if(ptr == NULL) {
        return false;
    }
    metadata_block* check;
    check = ptr - METADATA_SIZE;
    return ptr == check -> check_ptr;
}


/**
 * round up the block size to 8n to align memory
 * @param  size input size
 * @return      output size of 8n
 */
size_t round_up_to8(size_t size) {
    return (size % 8) ? ((size / 8) + 1) * 8 : size;
}

/**
 * print the free_blocks list for debugging purpose
 */
void print_free_list() {
    if(!free_head) {
        printf("debug info: free head is NULL\n");
    }
    else {
        metadata_block* t = free_head;
        printf("debug info: free node size ");
        while(t) {
            if(t -> free_prev) {
                printf("<-");
            }
            printf(" (%d) ", (int)t -> size);
            if(t -> free_next) {
                printf("->");
            }
            t = t -> free_next;
        }
        printf("\n");
    }
}

void print_free_list_TLS(metadata_block* h) {
    if(!h) {
        printf("debug info: free head is NULL\n");
    }
    else {
        metadata_block* t = h;
        printf("debug info: free node size ");
        while(t) {
            if(t -> free_prev) {
                printf("<-");
            }
            printf(" (%d) ", (int)t -> size);
            if(t -> free_next) {
                printf("->");
            }
            t = t -> free_next;
        }
        printf("\n");
    }
}

void check_free_list_TLS(metadata_block* h) {
    if(!h) {
        // printf("debug info: free head is NULL\n");
    }
    else {
        metadata_block* t = h;
        metadata_block* p = NULL;
        int i = 0;
        while(t) {
            i++;
            if(t -> free_prev != p) {
                printf("debug info: free prev error, index(%d)\n", i);
            }
            p = t;
            t = t -> free_next;
            if(p -> free_next != t) {
                printf("debug info: free next error\n");
            }
        }
        // printf("\n");
    }
}


void check_list_TLS(metadata_block* h) {
    if(!h) {
        // printf("debug info: free head is NULL\n");
    }
    else {
        metadata_block* t = h;
        metadata_block* p = NULL;
        int i = 0;
        while(t) {
            i++;
            if(t -> prev != p) {
                printf("debug info: prev error, index(%d)\n", i);
            }
            p = t;
            t = t -> next;
            if(p -> next != t) {
                printf("debug info: next error\n");
            }
        }
        // printf("\n");
    }
}

/**
 * add a free block to the free list, manipulate its
 * prev and next pointers
 * @param b the block to be added
 */
void add_to_free_list(metadata_block* b) {
    if(!free_head) {
        free_head = b;
        b -> free_prev = NULL;
        b -> free_next = NULL;
        return;
    }
    else {
        metadata_block* t = free_head;
        metadata_block* p = NULL;
        while(b > t && t) {
            p = t;
            t = t -> free_next;
        }
        if(!t) {  // append to tail
            p -> free_next = b;
            b -> free_prev = p;
            b -> free_next = NULL;
            return;
        }
        else if(b < free_head) {  // append to head
            b -> free_next = free_head;
            b -> free_prev = NULL;
            free_head -> free_prev = b;
            free_head = b;
            return;
        }
        else if(b == free_head) {  // the block came from merging
            printf("Warning. it's impossible!!!!\n");
        }
        else {  // add this node to middle
            b -> free_prev = p;
            b -> free_next = t;
            t -> free_prev = b;
            p -> free_next = b;
        }
    }
}

void add_to_free_list_TLS(metadata_block* b) {
    if(!free_head_TLS) {
        free_head_TLS = b;
        b -> free_prev = NULL;
        b -> free_next = NULL;
        return;
    }
    else {
        metadata_block* t = free_head_TLS;
        metadata_block* p = NULL;
        while(b > t && t) {
            p = t;
            t = t -> free_next;
        }
        if(!t) {  // append to tail
            p -> free_next = b;
            b -> free_prev = p;
            b -> free_next = NULL;
            return;
        }
        else if(b < free_head_TLS) {  // append to head
            b -> free_next = free_head_TLS;
            b -> free_prev = NULL;
            free_head_TLS -> free_prev = b;
            free_head_TLS = b;
            return;
        }
        else if(b == free_head_TLS) {  // the block came from merging
            printf("Warning. it's impossible!!!!\n");
        }
        else {  // add this node to middle
            b -> free_prev = p;
            b -> free_next = t;
            t -> free_prev = b;
            p -> free_next = b;
        }
    }
}

/**
 * remove a block from free_blocks list
 * @param b the block to be removed
 */
void remove_from_free_list(metadata_block* b) {
    if(free_head == b) {
        free_head = b -> free_next;
        if(b -> free_next) {
            b -> free_next -> free_prev = NULL;
        }
        b -> free_prev = NULL;
        b -> free_next = NULL;
    }
    else {
        if(b -> free_next) {  // not the tail
            b -> free_prev -> free_next = b -> free_next; 
            b -> free_next -> free_prev = b -> free_prev;
            b -> free_prev = NULL;
            b -> free_next = NULL;
        }
        else {
            b -> free_prev -> free_next = NULL;
            b -> free_prev = NULL;
            b -> free_next = NULL;
        }
    }
}

void remove_from_free_list_TLS(metadata_block* b) {
    if(free_head_TLS == b) {  // head of the free list
        free_head_TLS = b -> free_next;
        if(b -> free_next) {
            b -> free_next -> free_prev = NULL;
        }
        b -> free_prev = NULL;
        b -> free_next = NULL;
    }
    else {  // not the head
        if(b -> free_next) {  // not the tail
            b -> free_prev -> free_next = b -> free_next; 
            b -> free_next -> free_prev = b -> free_prev;
            b -> free_prev = NULL;
            b -> free_next = NULL;
        }
        else {  // the tail
            b -> free_prev -> free_next = NULL;
            b -> free_prev = NULL;
            b -> free_next = NULL;
        }
    }
}

/**
 * merge adjacent blocks in main list. when 2 blocks are 
 * adjacent to each other in the main list and are both
 * free, merge them into 1 block and re-connect the ptrs.
 *
 * will traverse to the first possible free block in main
 * list, and merge onward until no more adjacent free block
 * found.
 * 
 * @param b a free block to be merged with its neighbors
 */
void merge_adjacent(metadata_block* b) {  // metadata_block* 
    metadata_block* temp_free;
    metadata_block* temp_b;
    // first, loop towards the first consecutive free block
    if(b -> prev) {
        while(b -> prev && b -> prev -> is_free) {
            b = b -> prev;
        }
    }
    temp_b = b;
    // free all the following blocks until reach the end or not free.
    while(b -> next && b -> next -> is_free) {
        b -> size += METADATA_SIZE + b -> next -> size;
        b -> next = b -> next -> next;
    }
    
    if(b -> next) {  // if b->next is not NULL, then it's not free
        temp_free = b -> next -> prev;
        b -> next -> prev = b;

        if(temp_free -> free_next) {
            temp_free -> free_next -> free_prev = temp_b;
            temp_b -> free_next = temp_free -> free_next;
        }
        else {
            temp_b -> free_next = NULL;
        }
    }
    else {  // if b->next is NULL, then b eats up all remaining space
        temp_b -> free_next = NULL;
        tail = temp_b;  // the new end of the blocks
    }
    // printf("debug info: after merge, the size is %d\n", b -> size);
}

/**
 * check the adjacency of two blocks on full list. true: adjacent in free list; false: not adjacent
 * @param  prev previous pointer
 * @param  curr current pointer
 * @return      true or false
 */
bool check_consecutiveness(metadata_block* prev, metadata_block* curr) {
    metadata_block* temp;
    void* p = prev;
    p = (char*)p + prev -> size + METADATA_SIZE;
    temp = p;
    if(temp -> start_ptr == curr -> start_ptr) {
    	// printf("Info. can return true\n");
        return true;
    }
    // printf("Info. can return false\n");
    return false;
}

void merge_adjacent_TLS(metadata_block* b) {  // metadata_block* 
    metadata_block* temp_b;
    metadata_block* temp_b_check;
    temp_b = b;
    // first, loop towards the first consecutive free block
    if(temp_b -> free_prev) {
        temp_b = temp_b -> free_prev;  // move to the previous free block
        while(temp_b -> free_prev && check_consecutiveness(temp_b -> free_prev, temp_b)) {
            temp_b_check = temp_b;
            temp_b = temp_b -> free_prev;
            if(temp_b -> free_next != temp_b_check) {
                printf("Warning. free list wrong.\n");
            }
        }
    }
    else {
        return;  // no free_prev, nothing to merge
    }
    if(b == temp_b || temp_b -> free_next == b) {
        // printf("Info. no merge here.\n");
        return;  // nothing to merge here
    }
    // free all the following blocks until reach the provided.
    while(temp_b -> free_next != b) {
        temp_b -> size += METADATA_SIZE + temp_b -> free_next -> size;
        temp_b_check = temp_b -> free_next;
        if(temp_b -> free_next > b) {
            printf("Warning. merge impossible.\n");
        }
        temp_b -> free_next = temp_b -> free_next -> free_next;

    }
    // temp_b -> free_next reached b.
    if(temp_b_check -> next == b) {
        temp_b -> next = b;
        temp_b -> free_next = b;
        b -> prev = temp_b;
        b -> free_prev = temp_b;
    }
    else {
        temp_b_check -> next -> prev = temp_b;
        b -> free_prev = temp_b;
        temp_b -> free_next = b;
        temp_b -> next = temp_b_check -> next;
    }
}

/**
 * split a large block into 2 smaller blocks, if it 
 * can hold sie + METADATA_SIZE
 * @param b    the block to be splitted
 * @param size the size for the first block
 */
void split_block(metadata_block* b, size_t size) {
    if((b -> size - size) <= (METADATA_SIZE)) {
        // printf("debug info: too small not split\n");
        return;  // do not split if too small
    }
    metadata_block* temp;
    void* p = b -> start_ptr;
    // printf("debug info: temp start at %x\n", p);
    p = (char*)p + size;
    temp = p;
    // printf("debug info: temp start at2 %x\n", p);
    temp -> size = b -> size - METADATA_SIZE - size;
    temp -> is_free = true;
    temp -> prev = b;
    
    if(b -> next) {
    	temp -> next = b -> next;
        b -> next -> prev = temp;
        if(b -> next -> is_free) {
        	b -> next -> free_prev = temp;
    	}
    }
    else {
    	temp -> next = NULL;
    	tail = temp;
    }
    temp -> free_prev = b;
    
    if(b -> free_next) {
    	temp -> free_next = b -> free_next;
        temp -> free_next -> free_prev = temp;
    }
    else {
    	temp -> free_next = NULL;
    }
    temp -> check_ptr = temp + 1;
    temp -> start_ptr = temp + 1;
    b -> size = size;
    b -> next = temp;
    b -> free_next = temp;
}


void split_block_TLS(metadata_block* b, size_t size) {
    if((b -> size - size) <= (METADATA_SIZE) || b == tail_TLS || b == head_TLS || b == free_head_TLS) {
        // printf("debug info: too small not split\n");
        return;  // do not split if too small
    }
    if(!(b -> next) || !(b -> prev)) {
        printf("warning: just impossible\n");
        return;
    }
    metadata_block* temp;
    void* p = b -> start_ptr;
    // printf("debug info: temp start at %x\n", p);
    p = (char*)p + size;
    temp = p;
    // printf("debug info: temp start at2 %x\n", p);
    temp -> size = b -> size - METADATA_SIZE - size;
    temp -> is_free = true;
    temp -> prev = b;
    temp -> free_prev = b;
    temp -> next = b -> next;
    temp -> free_next = b -> free_next;
    temp -> check_ptr = temp + 1;
    temp -> start_ptr = temp + 1;
    

    b -> next -> prev = temp;
    if(b -> free_next) {
        b -> free_next -> free_prev = temp;    
    }
    b -> next = temp;
    b -> free_next = temp;
    b -> size = size;


    // if(b -> next) {
    //     temp -> next = b -> next;
    //     b -> next -> prev = temp;
    //     if(b -> next -> is_free) {
    //         b -> next -> free_prev = temp;
    //         temp -> free_next = b -> next;
    //     }
    //     else {
    //         b -> next -> free_prev = NULL;   
    //     }
    // }
    // else {  // already the last
    //     temp -> next = NULL;
    //     temp -> free_next = NULL;
    //     tail_TLS = temp;  // write to TLS pointer

    //     // printf("debug info: still reached the end\n");
    // }
    
    // if(b -> free_next) {
    //     temp -> free_next = b -> free_next;
    //     b -> free_next -> free_prev = temp;
    // }
    // else {
    //     temp -> free_next = NULL;
    // }
    // temp -> check_ptr = temp + 1;
    // temp -> start_ptr = temp + 1;
    // b -> size = size;
    // b -> next = temp;
    // b -> free_next = temp;
    
}


/**
 * my implementation of free function for both malloc's
 * @param ptr the address of start_ptr of a block
 */
// void my_free(void *ptr) {
//     metadata_block* temp;
//     metadata_block* temp_head;
// 	if(!ptr || !metadata_check(ptr)) {
//         printf("Error! not freed\n");
// 		return;
// 	}
//     temp = ptr - METADATA_SIZE;
//     temp -> is_free = true;
//     add_to_free_list(temp);
//     merge_adjacent(temp);
//     // MARK:- no need to brk the last block right now.
// }

/**
 * use best fit method to find a block.
 * @param  size the size of block to be found
 * @return      the pointer to the head of the found block
 */
metadata_block* best_fit_find(size_t size) {
    metadata_block* t = free_head;
    metadata_block* best = NULL;
    size_t diff = SIZE_MAX;
    size_t temp_diff;
    while(t != NULL) {
        if(t -> size >= size) {
            temp_diff = t -> size - size;
            if(temp_diff == 0) {  // end when find exact size
                best = t;
                return best;
            }
            if(temp_diff < diff) {
                diff = temp_diff;
                best = t;
            }
            t = t -> free_next;
            continue;
        }
        else {
            t = t -> free_next;
            continue;
        }
    }
    return best;  // found or NULL
}


metadata_block* best_fit_find_TLS(metadata_block* h, size_t size) {
    metadata_block* t = h;
    metadata_block* best = NULL;
    size_t diff = SIZE_MAX;
    size_t temp_diff;
    while(t != NULL) {
        if(t -> size >= size) {
            temp_diff = t -> size - size;
            if(temp_diff == 0) {  // end when find exact size
                best = t;
                return best;
            }
            if(temp_diff < diff) {
                diff = temp_diff;
                best = t;
            }
            t = t -> free_next;
            continue;
        }
        else {
            t = t -> free_next;
            continue;
        }
    }
    return best;  // found or NULL
}

/**
 * append a chunk to main list if no free block available to hold
 * the requested size.
 * @param  prev the tail of current main list
 * @param  size the size requested
 * @return      a pointer to the head of newly allocated memory
 */
metadata_block* append_space(metadata_block* prev, size_t size) {
    metadata_block* new;
    void* end;
    pthread_mutex_lock(&sbrk_lock);  // lock for ver2
    new = sbrk(0);
    end = sbrk(METADATA_SIZE + size);
    pthread_mutex_unlock(&sbrk_lock);
    // printf("debug info: METADATA_SIZE is %d\n", METADATA_SIZE);
    // printf("debug info: alloc'd space at %x\n", new);
    if(end == (void *) - 1) {
        return NULL;  // sbrk failed
    }
    new -> size = size;
    new -> is_free = false;
    new -> prev = prev;
    new -> next = NULL;
    new -> free_prev = NULL;
    new -> free_next = NULL;
    new -> check_ptr = new + 1;
    new -> start_ptr = new + 1;  // a ptr to the beginning of data seg
    if(prev != NULL) {
        prev -> next = new;
        tail = new;
    }
    return new;  // usable addr
}

metadata_block* append_space_TLS(metadata_block* prev, size_t size) {
    metadata_block* new;
    void* end;
    pthread_mutex_lock(&sbrk_lock);  // lock for ver2
    new = sbrk(0);
    end = sbrk(METADATA_SIZE + size);
    pthread_mutex_unlock(&sbrk_lock);
    // printf("debug info: METADATA_SIZE is %d\n", METADATA_SIZE);
    // printf("debug info: alloc'd space at %x\n", new);
    if(end == (void *) - 1) {
        return NULL;  // sbrk failed
    }
    new -> size = size;
    new -> is_free = false;
    new -> prev = prev;
    new -> next = NULL;
    new -> free_prev = NULL;
    new -> free_next = NULL;
    new -> check_ptr = new + 1;
    new -> start_ptr = new + 1;  // a ptr to the beginning of data seg
    if(prev != NULL) {
        prev -> next = new;
        // *t = new;  // write to TLS pointer
        tail_TLS = new;
    }
    return new;  // usable addr
}

/* ================================================================ */
/* HW funcs */

void *ts_malloc_lock(size_t size) {
    size = round_up_to8(size);
    metadata_block* current;
    if(size <= 0) {
        return NULL;  // invalid case, just return NULL ptr
    }

    pthread_mutex_lock(&lock);
    if(head == NULL) {  // first malloc
        current = append_space(NULL, size);
        head = current;
        tail = current;
        pthread_mutex_unlock(&lock);
        return current -> start_ptr;  // fail: NULL, succeed: (new)
    }
    else {
        current = best_fit_find(size);
        // printf("debug info: temp_prev is %x\n", temp_prev);
        if(current == NULL) {  // not found
            current = append_space(tail, size);
            pthread_mutex_unlock(&lock);
            return current -> start_ptr;
        }
        else {
            split_block(current, size);
            current -> is_free = false;
            remove_from_free_list(current);
            pthread_mutex_unlock(&lock);
            return current -> start_ptr;
        }
    }
}

void ts_free_lock(void *ptr) {
    metadata_block* temp;
    // metadata_block* temp_head;
    if(!ptr || !metadata_check(ptr)) {
        printf("Error! not freed\n");
        return;
    }
    pthread_mutex_lock(&lock);
    temp = ptr - METADATA_SIZE;
    temp -> is_free = true;
    add_to_free_list(temp);
    merge_adjacent(temp);
    pthread_mutex_unlock(&lock);
}

void *ts_malloc_nolock(size_t size) {
    // print_free_list_TLS(free_head_TLS);
    // check_free_list_TLS(free_head_TLS);
    // check_list_TLS(head_TLS);
    size = round_up_to8(size);
    metadata_block* current;
    if(size <= 0) {
        return NULL;  // invalid case, just return NULL ptr
    }

    if(head_TLS == NULL) {  // first malloc for a thread
        current = append_space_TLS(NULL, size);  // write to TLS pointer
        head_TLS = current;  // write to TLS pointer
        tail_TLS = current;  // write to TLS pointer
        return current -> start_ptr;  // fail: NULL, succeed: (new)
    }
    else {
        current = best_fit_find_TLS(free_head_TLS, size);  // read from TLS pointer
        // printf("debug info: temp_prev is %x\n", temp_prev);
        if(current == NULL) {  // not found
            current = append_space_TLS(tail_TLS, size);  // write to TLS pointer
            tail_TLS = current;  // write to TLS pointer
            return current -> start_ptr;
        }
        else {
            // split_block_TLS(current, size);  // write to TLS pointer
            current -> is_free = false;
            remove_from_free_list_TLS(current);  // rw TLS pointer
            return current -> start_ptr;
        }
    }
}

void ts_free_nolock(void *ptr) {
    metadata_block* temp;
    // metadata_block* temp_head;
    if(!ptr || !metadata_check_TLS(ptr)) {
        printf("Error! not freed\n");
        return;
    }
    temp = ptr - METADATA_SIZE;
    temp -> is_free = true;
    add_to_free_list_TLS(temp);  // rw TLS pointer
    // merge_adjacent_TLS(temp);  // merge is already bug free. fix split function.
}

/* ================================================================ */
