#include "exerciser.h"

void exercise(connection *C)
{

}
